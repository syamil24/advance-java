package com.maybank.weekendtraining2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Weekendtraining2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
