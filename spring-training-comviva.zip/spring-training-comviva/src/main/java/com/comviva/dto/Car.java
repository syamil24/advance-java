package com.comviva.dto;

public class Car {

	private String brand;

	private int cost;

	public Car(String brand, int cost) {
		this.brand = brand;
		this.cost = cost;
		System.out.println("Car(String brand, int cost) called");
	}
	
	public Car(String brand, String cost) {
		this.brand=brand;
		this.cost=Integer.parseInt(cost);
		System.out.println("Car(String brand, String cost) called");
	}

	public String getBrand() {
		return brand;
	}

	public int getCost() {
		return cost;
	}

	@Override
	public String toString() {
		return "Car [brand=" + brand + ", cost=" + cost + "]";
	}
	
	
	

}
