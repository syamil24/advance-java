package com.comviva.dto;

public class DatabaseOperations {

	public DatabaseOperations() {
		System.out.println("DatabaseOperations object created");
	}
	
	public void init() {
		System.out.println("Creating connection to database");
	}
	
	public void sendQuery(String query) {
		System.out.println("Sending query to database");
	}
	
	public void close() {
		System.out.println("Closing connection with database");
	}
}
