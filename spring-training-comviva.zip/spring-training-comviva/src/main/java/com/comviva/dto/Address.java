package com.comviva.dto;

public class Address {

	public Address() {
		System.out.println("Address object created");
	}
}
