package com.comviva.dto;

public class Student{
	
	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Student() {
		System.out.println("Student constructor called");
	}
	
	public void test() {
		System.out.println("Init method called");
	}
	
	
}
