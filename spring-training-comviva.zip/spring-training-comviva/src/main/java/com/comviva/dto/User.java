package com.comviva.dto;

public class User {

	public User() {
		System.out.println("User object created");
	}
	
	public void init() {
		System.out.println("User init method called");
	}
	
	public void destroy() {
		System.out.println("User destroy method called");
	}
}
