package com.comviva.containers;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.comviva.dto.DatabaseOperations;
import com.comviva.dto.Student;

public class ContainerTest1 {

	public static void main(String[] args) {
		Resource rs=new ClassPathResource("beans.xml");
		BeanFactory container=new XmlBeanFactory(rs);
		System.out.println("Beanfactory container initialization completed");
		
		Student s=(Student)container.getBean("s");
		
		System.out.println(s);
		
		DatabaseOperations db=(DatabaseOperations) container.getBean("dataBaseOperation");

	}
}
