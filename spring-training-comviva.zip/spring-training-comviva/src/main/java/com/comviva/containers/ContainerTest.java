package com.comviva.containers;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.comviva.dto.Address;
import com.comviva.dto.Car;
import com.comviva.dto.DatabaseOperations;
import com.comviva.dto.Person;
import com.comviva.dto.PrivateMessage;
import com.comviva.dto.PublicMessage;
import com.comviva.dto.Student;
import com.comviva.dto.User;

public class ContainerTest {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext container = new ClassPathXmlApplicationContext("beans.xml");
		System.out.println("Container initialization completed");

		System.out.println("-------------------------------------------------------");

		Student s = (Student) container.getBean("s");

		System.out.println(s.getName());

		Student s1 = (Student) container.getBean("s");

		System.out.println(s1);

		DatabaseOperations db = (DatabaseOperations) container.getBean("dataBaseOperation");

		db.sendQuery("select * from student");

		System.out.println("----------------------------------------");
		User u = (User) container.getBean("user");

		System.out.println(u);

		User u1 = (User) container.getBean("user");

		System.out.println(u1);

		System.out.println(container.getBean("user"));

		Address a = (Address) container.getBean("address");
		System.out.println(a);
		System.out.println(container.getBean("address"));

		Car car = (Car) container.getBean("car");

		System.out.println(car.getBrand() + "  " + car.getCost());

		System.out.println(car);

		PrivateMessage privateMessage = (PrivateMessage) container.getBean("privateMessage");

		PublicMessage publicMessage = (PublicMessage) container.getBean("publicMessage");
		
		System.out.println(privateMessage);
		
		System.out.println(publicMessage);
	

		container.close();

		// 5 scopes
		// singleton
		// prototype
		// request
		// session
		// application

	}
}
