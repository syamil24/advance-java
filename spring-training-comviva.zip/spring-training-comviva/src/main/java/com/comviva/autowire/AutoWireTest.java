package com.comviva.autowire;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AutoWireTest {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext container = new ClassPathXmlApplicationContext("beans-autowire.xml");
		Employee emp=(Employee)container.getBean("employee");
		System.out.println(emp.getAddress().getCity());
		
		
		Person p=(Person)container.getBean("person");
		
		System.out.println(p);
		
		container.close();
	}
}
