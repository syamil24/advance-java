package com.comviva.autowire;

public class Person {

	private String name;

	private Laptop laptop;

	public Person(String name, Laptop laptop) {
		this.name = name;
		this.laptop = laptop;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", laptop=" + laptop + "]";
	}
	
	

}
